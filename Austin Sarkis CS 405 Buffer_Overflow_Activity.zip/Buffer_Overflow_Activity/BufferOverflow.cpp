// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;
  const std::string account_number = "CharlieBrown42";
  // Plain C-array to store user input
  // 21 Bytes to store 20 characters + null terminator
  char user_input[21];
  std::cout << "Enter a value: ";

  // This will read up to 20 characters
  // Failure will occur if the input exceeds the buffer size
  std::cin.getline(user_input, sizeof(user_input));

  // Check if the input failed
  if (std::cin.fail()) {
	  // Clear the error state
      std::cin.clear();
	  // Ignore the rest of the line
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	  // Notify the user
      std::cerr << "Error: input exceeds " << sizeof(user_input) - 1 << " characters." << std::endl;
  }

  // No overflow occurred, proceed with the program
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
