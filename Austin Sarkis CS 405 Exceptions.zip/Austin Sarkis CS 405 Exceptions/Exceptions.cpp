#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>

// Custom exception type
class CustomException : public std::exception {
    std::string message_;
public:
	// Constructor to initialize the error message
    explicit CustomException(const std::string& message)
        : message_(message) {
    }

    // Return the stored error message
    const char* what() const noexcept override {
        return message_.c_str();
    }
};

// Simulate deeper application logic and throw a runtime error
bool do_even_more_custom_application_logic() {
    throw std::runtime_error("Error in Even More Custom Application Logic");

    // Unreachable code illustrating normal flow
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    return true;
}

// Execute application logic with standard exception handling
void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic succeeded." << std::endl;
        }
    }
	// Catch errors from deeper application logic
    catch (const std::exception& e) {
        // Log the error and continue processing
        std::cerr << "Error in custom logic: " << e.what() << std::endl;
    }

    // Throw a custom exception for higher-level handling
    throw CustomException("Custom exception thrown from Custom Application Logic");

    // Unreachable code illustrating normal flow
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Divide two floats and validate denominator
float divide(float numerator, float denominator) {
	// Check for division by zero and throw an exception if it occurs
    if (denominator == 0.0f) {
        throw std::invalid_argument("Division by zero error");
    }
    return numerator / denominator;
}

// Perform division and catch only division by zero errors
void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0.0f;

    try {
        float result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // Handle invalid argument from divide().
    catch (const std::invalid_argument& e) {
        std::cerr << "Error in division: " << e.what() << std::endl;
    }
}

int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
        do_custom_application_logic();

    }
	// Catch custom exceptions thrown from application logic
    catch (const CustomException& e) {
        
        std::cerr << "Caught CustomException in main: " << e.what() << std::endl;

    }
	// Handle standard exceptions
    catch (const std::exception& e) {
        std::cerr << "Caught std::exception in main: " << e.what() << std::endl;

    }
	// Catch any other unexpected exceptions
    catch (...) {
        std::cerr << "Caught unknown exception in main." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu